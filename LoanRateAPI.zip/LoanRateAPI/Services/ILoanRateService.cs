using LoanRatesApi.Models;
using System.Collections.Generic;

namespace LoanRatesApi.Services
{
    // Interface for rate retrieval
    public interface ILoanRateService
    {
        //Returns a list of rates that match the given loan type and term
        IEnumerable<Rate> GetRates(string loanType, int term);
    }
}