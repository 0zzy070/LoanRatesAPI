using LoanRatesApi.Models;
using System.Collections.Generic;
using System.Linq;

namespace LoanRatesApi.Services
{
    // Concrete service implementing ILoanRateService
    public class LoanRateService : ILoanRateService
    {
        // Mock rate data
        private static readonly List<Rate> Rates = new()
        {
            new Rate { LoanType = "owner-occupied", Term = 30, InterestRate = 5.5m },
            new Rate { LoanType = "investor", Term = 30, InterestRate = 6.2m },
            new Rate { LoanType = "owner-occupied", Term = 15, InterestRate = 4.8m }
        };

        public IEnumerable<Rate> GetRates(string loanType, int term)
        {
            // Return rates matching both criteria
            return Rates.Where(r => r.LoanType == loanType && r.Term == term);
        }
    }
}