using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using LoanRatesApi.Models;
using LoanRatesApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Register the loan rate service for dependency injection
builder.Services.AddScoped<ILoanRateService, LoanRateService>();

var app = builder.Build();


// Minimal API endpoint to retrieve loan interest ratesapp.MapGet("/api/loanrates", (string loanType, int term, ILoanRateService rateService) =>
{
    // Input validation for loanType if is not empty or just whitespace
    if (string.IsNullOrWhiteSpace(loanType))
        return Results.BadRequest("Loan type is required.");

    // Loan term validation, just a precautionary edge case (e.g., 1 to 40 years)
    if (term <= 0 || term > 40)
        return Results.BadRequest("Term must be between 1 and 40.");

    // Matching loan rates from static/mock data
    var rates = rateService.GetRates(loanType, term);

    // If no matching rates are found, return a 404 response
    if (!rates.Any())
        return Results.NotFound("No matching loan rates found.");

    return Results.Ok(rates);
});

app.Run(); 
