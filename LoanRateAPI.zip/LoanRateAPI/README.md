# LoanRatesAPI

A minimal .NET Core Web API that returns mock loan interest rates based on query parameters.

This project showcases clean architectural design using the Minimal API approach and SOLID principles. It includes static/mock data and is structured for easy extensibility and maintainability — ideal for demonstration or rapid prototyping.

---

## 🔗 Endpoint

```

GET /api/rates?loanType=owner-occupied\&term=30

```

Returns interest rate(s) for a given loan type and term.

---

## 🚀 Features

- ✅ Built using **.NET Core Minimal API**
- ✅ Applies **SOLID principles** via services and interfaces
- ✅ Lightweight, clean, and modular
- ✅ Uses static/mock data for simplicity
- ✅ Easy to test, extend, or integrate

---

## 🧪 Sample Response

```json
[
  {
    "loanType": "owner-occupied",
    "term": 30,
    "interestRate": 5.5
  }
]
```

---

## 📦 Project Structure

```
- Program.cs                 // Entry point with Minimal API logic
- Models/
  └─ Rate.cs                // Data model for loan rate
- Services/
  ├─ IRateService.cs        // Interface defining contract for rate service
  └─ RateService.cs         // Service with mock/static data implementation
```

---

## 🛠️ How to Run

1. **Clone the project:**

   ```bash
   git clone https://github.com/0zzy070/LoanRatessAPI.git
   cd LoanRatesAPI
   ```

2. **Run the API:**

   ```bash
   dotnet run
   ```

3. **Test the endpoint:**

   Open a browser or API tool like Postman and go to:

   ```
   http://localhost:5000/api/rates?loanType=owner-occupied&term=30
   ```

   > ℹ️ If port 5000 is not used, check the console output for the actual port.

---

## 👤 About

This project was built as part of a technical interview to demonstrate clean, well-structured API development with .NET Core. It focuses on clarity, simplicity, and adherence to best practices — especially around code readability, separation of concerns, and maintainability.

---

## 📄 License

MIT License — feel free to use, share, or build upon this.

```

---

🙋‍♂️ Why I Built This

This project was created as a coding sample to demonstrate clean architecture and minimal APIs in .NET Core. It can be used as a starter template for small Web APIs.

⸻
```
